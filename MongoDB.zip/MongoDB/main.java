package MongoDB;

import java.util.Scanner;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.*;

public class main {

	public static void main(String[] args) {
		//Conexion al MongoDB
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("biblioteca");
		MongoCollection<Document> coleccion = database.getCollection("libro");
		//Switch para elegir la opcion
		System.out.println("Elije una opci�n");
		System.out.println("1. Mostrar todo");
		System.out.println("2. Mostrar libro");
		System.out.println("3. Crear");
		System.out.println("4. Actualizar");
		System.out.println("5. Eliminar");

		Scanner teclado = new Scanner(System.in);
		int num = teclado.nextInt();

		switch (num) {

		case 1:
			mostrarTodo(coleccion);
			break;

		case 2:
			mostrarLibro(coleccion);
			break;
		case 3:
			crearLibro(coleccion);
			break;
		case 4:
			actualizar(coleccion);
			break;
		case 5:
			borrar(coleccion);
			break;

		}

	}

	public static void crearLibro(MongoCollection<Document> coleccion) {
		//Creas un libro
		Scanner teclado = new Scanner(System.in);

		System.out.println("Dime la id");
		String id = teclado.next();

		System.out.println("Dime el titulo");
		String titulo = teclado.next();

		System.out.println("Dime el autor");
		String autor = teclado.next();

		System.out.println("Dime el a�o de nacimiento");
		String anyo_nac = teclado.next();

		System.out.println("Dime el a�o de publicaci�n");
		String anyo_publi = teclado.next();

		System.out.println("Dime la editorial");
		String editorial = teclado.next();

		System.out.println("Dime el numero de paginas");
		String num_pag = teclado.next();
		//Insertas los valores a la base de datos de MongoDB
		Document doc = new Document();
		doc.append("Id", id);
		doc.append("Titol", titulo);
		doc.append("Autor", autor);
		doc.append("Any_naixement", anyo_nac);
		doc.append("Any_publicacio", anyo_publi);
		doc.append("Editorial", editorial);
		doc.append("Nombre_pagines", num_pag);

		coleccion.insertOne(doc);

	}

	public static void actualizar(MongoCollection<Document> coleccion) {
		
		Scanner teclado = new Scanner(System.in);
		//Actualizas el campo de libro
		System.out.println("Dime que campo quieres actualizar");
		String campo = teclado.next();

		System.out.println("Dime el campo actual");
		String campoactual = teclado.next();

		System.out.println("Dime que campo quieres poner");
		String campo_actualizado = teclado.next();
		//Primero pones lo que quieres actualizar y despues lo que el dato que vas a actualizar
		coleccion.updateOne(eq(campo, campoactual), new Document("$set", new Document(campo, campo_actualizado)));

	}

	public static void borrar(MongoCollection<Document> coleccion) {
		Scanner teclado = new Scanner(System.in);
		
		System.out.println("Dime que id de libro quieres borrar");
		String campo = teclado.next();
		//Pones el id que quieres borrar
		Bson query = eq("Id", campo);
		MongoCursor<Document> cursor = coleccion.find(query).iterator();
		//Se borra la ID
		while (cursor.hasNext()) {
			System.out.println(cursor.next().toJson());
			coleccion.deleteMany(eq("Id", campo));

		}

	}
	public static void mostrarTodo(MongoCollection<Document> coleccion) {
			//Conectas a la base de datos
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("biblioteca");
		 coleccion = database.getCollection("libro");
		 //Mostras los datos de todos los libros
		Bson query = eq("Id", "");
		MongoCursor<Document> cursor = coleccion.find().iterator();
		while (cursor.hasNext()) {
			System.out.println(cursor.next().toJson());
		}
		
		Bson query2 = eq("Titol", "");
		
		MongoCursor<Document> cursor2 = coleccion.find().iterator();
		while (cursor.hasNext()) {
		System.out.println(cursor.next().toJson());
		}
	}
	
	public static void mostrarLibro(MongoCollection<Document> coleccion) {
		Scanner teclado = new Scanner(System.in);
		//Conectas a la base de datos
		MongoClient mongoClient = new MongoClient("localhost", 27017);
		MongoDatabase database = mongoClient.getDatabase("biblioteca");
		 coleccion = database.getCollection("libro");
		 //Muestras el libro segun la id que quieras
		 System.out.println("Dime la id que quieres buscar");
		 String id = teclado.next();
		Bson query = eq("Id", id);
		MongoCursor<Document> cursor = coleccion.find(query).iterator();
		while (cursor.hasNext()) {
			System.out.println(cursor.next().toJson());
		}
	}
}
