package T1E1_Evaluable;

/**
 * @author Alex Ripoll P�rez 2�DAM
 *
 */
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import Tema1.Directorio;

public class Ejer1 {
	
	public static void main(String[] args) {
		// Creamos un variable donde guardamos el parametro args
		String directorio = args[0];
		
		Scanner sc = new Scanner(System.in);
		// Hacemos switch para elegir el metodo
		int valor = 2;
		while (valor > 0 && valor < 6) {
			System.out.println("1.- Informacion");
			System.out.println("2.- Crear carpeta");
			System.out.println("3.- Crear fichero");
			System.out.println("4.- Eliminar");
			System.out.println("5.- Renombrar");
			break;
		}
		System.out.println("Dime un numero");
		int value = sc.nextInt();

		switch (value) {
		case 1: {

			getInformacio(directorio);
			break;
		}
		case 2: {
			creaCarpeta();
			break;
		}
		case 3: {
			creaFitxer();
			break;
		}
		case 4: {
			elimina(directorio);
			break;
		}
		case 5: {
			renomena();
			break;
		}
		}

	}

	public static void getInformacio(String directorio) {
		//Creamos un File para que nos salga el texto que hemos pasado por argumentos
		File di = new File(directorio);
		// Con el .getName obtenemos el nombre que hemos pasado por argumentos
		System.out.println("El nombre del directorio es:" + di.getName());
		System.out.println("----------------");
		//Con el .lastModified mostramos la ultima fecha y hora de la modificaci�n
		long modificacion = di.lastModified();
		String fecha = "yyyy-MM-dd hh:mm";
		SimpleDateFormat data = new SimpleDateFormat(fecha);

		Date ultimaModif = new Date(modificacion);

		System.out.println("La ultima fecha de modificacion fue: " + data.format(ultimaModif));
		System.out.println("----------------");
		File oculto = new File("C:\\Ejer1T1\\directorio\\fichero1.txt");
		//Con el .isHidden te dice si esta oculto el archivo o no
		if (oculto.isHidden()) {
			System.out.println("Esta oculto el archivo");
		} else {
			System.out.println("No est� oculto");
		}
		System.out.println("----------------");
		//Con el .isDirectory te dice si es un directorio y en caso que no poniendo el .isFile te dice si es un fichero
		if (di.isDirectory()) {
			String list[] = di.list();
			//Con el .getFreeSpace te dice el espacio libre que queda
			System.out.println("El espacio libre que queda es: " + di.getFreeSpace());
			System.out.println("----------------");
			//Con el .getFreeSpace te dice el espacio usado
			System.out.println("El espacio usado es: " + di.getUsableSpace());
			System.out.println("----------------");
			//Con el .getFreeSpace te dice el espacio total que hay
			System.out.println("El espacio total es: " + di.getTotalSpace());
			System.out.println("----------------");
		}

		if (di.isFile()) {
			long size = di.length();
			System.out.println(size);
		}
	}

	public static void creaCarpeta() {
		// Para crear el fichero primero ponemos la ruta, despues con el .mkdir se crea la carpeta y opcionalmente pones un texto para que te diga si se ha creado correctamente
		File directorio = new File("C:\\Ejer1T1\\directorio");
		directorio.mkdir();
		System.out.println("Se ha creado correctamente la carpeta");
	}

	public static void creaFitxer() {
		//Para crear un fichero primero elijes la ruta y el nombre con el que quieres llamarle, despues con el .createNewFile lo creas
		File fi = new File("C:\\Ejer1T1\\directorio\\fichero1.txt");

		try {
			if (fi.createNewFile()) {
				System.out.println("Se ha creado correctamente");
			} else {
				System.out.println("No se ha podido crear");
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		System.out.println("----------------");

	}

	public static void elimina(String directorio) {
		//Para eliminar el fichero gastando el .delete borras el fichero que quieras
		File fichero = new File(directorio);

		if (fichero.delete()) {
			System.out.println("Se ha borrado correctamente");
		} else {
			System.out.println("No se pudo borrar");
		}
		System.out.println("----------------");
	}

	public static void renomena() {
		
		//Para renombrar el fichero primero pones la ruta donde esta situado, y despues a que nombre quieres cambiar
		File fichero1 = new File("C:\\Ejer1T1\\directorio\\fichero1.txt");

		File fichero2 = new File("C:\\\\Ejer1T1\\\\directorio\\\\fichero2.txt");

		if (fichero1.renameTo(fichero2)) {
			System.out.println("Se ha renombrado");
		} else {
			System.out.println("No se ha renombrado");
		}
		System.out.println("----------------");
	}
}