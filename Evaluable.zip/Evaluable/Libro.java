package Evaluable;
/*
 * @author Alex Ripoll Perez 2�DAM
 * @since 3/12/2021 
 */
public class Libro {
	//Atributos
	private int Id;
	private String Titulo;
	private String Autor;
	private String Editorial;
	private int Numero_paginas;
	//Constructor sin parametros
	public Libro() {
		
	}
	//Constructor con parametros
	public Libro(String Titulo, String Autor, String Editorial, int Numero_paginas) {
	
		this.Titulo = Titulo;
		this.Autor = Autor;
		this.Editorial = Editorial;
		this.Numero_paginas = Numero_paginas;

	}
	//Getters and Setters
	public int getId() {
		return Id;
	}

	public void setId(int Id) {
		this.Id = Id;
	}

	public String getTitulo() {
		return Titulo;
	}

	public void setTitulo(String titulo) {
		Titulo = titulo;
	}

	public String getAutor() {
		return Autor;
	}

	public void setAutor(String autor) {
		Autor = autor;
	}

	public String getEditorial() {
		return Editorial;
	}

	public void setEditorial(String editorial) {
		Editorial = editorial;
	}

	public int getNumero_paginas() {
		return Numero_paginas;
	}

	public void setNumero_paginas(int Numero_paginas) {
		this.Numero_paginas = Numero_paginas;
	}
	//Metodo toString
	@Override
	public String toString() {
		return "Libro Id=" + Id + ", Titulo=" + Titulo + ", Autor=" + Autor + ", Editorial=" + Editorial
				+ ", Numero_paginas=" + Numero_paginas + "";
	}
	
}
