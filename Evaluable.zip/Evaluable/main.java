package Evaluable;
/*
 * @author Alex Ripoll Perez 2�DAM
 * @since 3/12/2021
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.internal.build.AllowSysOut;
import org.hibernate.service.ServiceRegistry;

public class main {

	public static void main(String[] args) {
		
		//Cargas la configuracion y creas una sesion factory
		Scanner sc = new Scanner(System.in);
		Configuration configuration = new Configuration().configure("hibernate.cfg.xml");
		configuration.addClass(Libro.class);
		ServiceRegistry registry = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
				.build();
		SessionFactory sessionFactory = configuration.buildSessionFactory(registry);
		//Abres una sesion de la SesionFactory
		Session session = sessionFactory.openSession();
		session.beginTransaction();

		List listaLibro = new ArrayList();

		listaLibro = session.createQuery("FROM Libro").list();
		//Hago un switch donde eligo la opcion quiere quiero ejecutar
		System.out.println(
				"\n Elige un numero \n 1.-A�adir libro \n 2.- Actualizar libro \n 3.- Borrar libro \n 4.-Mostrar todos los libros \n 5.- Mostrar libro segun la ID");
		int opc = sc.nextInt();

		switch (opc) {
		//Si pulsas 1 a�ades un libro a la base de datos
		case 1:
			try {

				System.out.println("Dime el titulo del libro");
				String tit = sc.next();

				System.out.println("Dime el autor");
				String aut = sc.next();

				System.out.println("Dime la editorial");
				String edi = sc.next();

				System.out.println("Dime el numero de paginas");
				int num_pag = sc.nextInt();
				
				Libro libro = new Libro(tit, aut, edi, num_pag);
				Serializable id = session.save(libro);
				System.out.println("Se a�adi� correctamente");
			} catch (Exception e) {
				System.out.println("No se ha a�adido correctamente");
			}

			break;
			//Si pulsas 2 actualizas el libro segun la id que quieras modificar
		case 2:
			try {
				System.out.println("Dime la id que quieres actualizar");
				int id = sc.nextInt();
				Libro lbr = (Libro) session.load(Libro.class, id);
				
				System.out.println("Pulse 0 si quieres dejarlo como esta el campo o pulse 1 si quieres modificarlo");
				System.out.println("---------------");
				
				System.out.println("�Quieres cambiar el titulo?");
				
				int numtit = sc.nextInt();
				if(numtit==1) {
					System.out.println("Dime el titulo que quieres poner");
					String tit = sc.next();
					lbr.setTitulo(tit);
				}else {
					
				}
				System.out.println("---------------");
				System.out.println("�Quieres cambiar el autor?");
				int numaut = sc.nextInt();
				if(numaut==1) {
					System.out.println("Dime el autor que quieres poner");
					String aut = sc.next();
					lbr.setAutor(aut);
					
				}else {
					
				}
				System.out.println("---------------");
				System.out.println("�Quieres cambiar la editorial?");
				int numedi = sc.nextInt();
				if(numedi==1) {
					System.out.println("Dime la editorial que quieres poner");
					String edi = sc.next();
					lbr.setTitulo(edi);
					
				}else {
					
				}
				System.out.println("---------------");
				System.out.println("�Quieres cambiar el numero de paginas?");
				int num_num_pag = sc.nextInt();
				if(num_num_pag==1) {
					System.out.println("Dime el numero de paginas que quieres poner");
					int num_pag = Integer.parseInt(sc.next());
					lbr.setNumero_paginas(num_pag);
				}else {
					
				}
				session.update(lbr);
				System.out.println("Se actualiz� correctamente");
			} catch (Exception e) {
				System.out.println("No se actualiz� correctamente");
			}
			break;
			//Si pulsas 3 eliminas el libro
		case 3:
			try {
				System.out.println("Dime la id que quieres eliminar");
				int id = sc.nextInt();
				Libro lib = (Libro) session.load(Libro.class, id);
				lib.setId(1);
				session.delete(lib);
				System.out.println("Se elimin� el libro");
			} catch (Exception e) {
				System.out.println("No se elimino el libro");
			}
			break;
			//Si pulsas 4 muestras todos los libros
		case 4:
			List listaCanciones = new ArrayList();
			listaCanciones = session.createQuery("FROM Libro").list();

			for (int i = 0; i < listaCanciones.size(); i++) {
				System.out.println(listaCanciones.get(i).toString());
			}
			break;
			//Si pulsas 5 muestras el libro segun la id que quieras
		case 5:
			System.out.println("Dime la id que quieres mostrar");
			int id = sc.nextInt();
			Libro lib = (Libro) session.get(Libro.class, id);
			System.out.println(lib.toString());
			break;
		}
		//Cierras la sesion
		sc.close();
		session.getTransaction().commit();
		session.close();

	}

}
